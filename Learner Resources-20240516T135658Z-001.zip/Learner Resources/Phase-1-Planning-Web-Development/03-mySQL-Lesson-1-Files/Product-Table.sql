create table Product (
    pid     int,
    name    varchar(256),
    brand   varchar(256),
    price   int,
    color   varchar(256),
    ratings float
    );